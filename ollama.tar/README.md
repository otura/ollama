# README

Code to bring up Ollama using Docker (on GPU - Optionally)

Refer the blog for more details - [https://medium.com/@srpillai](https://medium.com/@srpillai)

## References

* [https://ollama.com/](https://ollama.com/)
* [https://github.com/ollama/ollama](https://github.com/ollama/ollama)
* [https://streamlit.io/](https://streamlit.io/)
* [https://docs.docker.com/desktop/gpu/](https://docs.docker.com/desktop/gpu/)